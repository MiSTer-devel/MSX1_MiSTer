CD CreateCRC
python3 createDB.py
CD ..\CreateMSXpack
python3 createComp.py
python3 createDev.py
CD ..
